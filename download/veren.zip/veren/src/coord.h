#ifndef COORD_H
#define COORD_H

#include "GL/gl.h"
#include "GL/glu.h"

struct Coord
{
       float x;
       float y;
       float z;
       float* GetAllCoord();
};


struct FullCoord
{
       float x;
       float y;
       float z;
	   float xr;
	   float yr;
	   float zr;
};

struct BeamCoord
{
		GLdouble shift;
		GLdouble dAngle, vAngle;
};


#endif //COORD_H
