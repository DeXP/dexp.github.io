/*
 * Guichan FPS Demo
 *
 * This is a demonstration of the Guichan GUI library and what it
 * is capable of.
 *
 * For more information about Guichan visit: http://guichan.sourceforge.net
 */

#include "dxbutton.hpp"

//int DXButton::mInstances = 0;
//Mix_Chunk* DXButton::mHoverSound = NULL;

/*
 * It is very important to call Buttons constructor in the constructor
 * initialization code so we do that. In the constructor execution code
 * we check instances and load the mouse hover sound if there are no
 * instances.
 */
DXButton::DXButton(const std::string& caption)
		:Button(caption),
         mHasMouse(false)
{
  setFrameSize(0);

  glyph = NULL;
  
/*	if (mInstances == 0)
	{		
		mHoverSound = Mix_LoadWAV("sound/sound5.wav");
		Mix_VolumeChunk(mHoverSound, 60);
	}
	
	++mInstances;*/
}


DXButton::DXButton(const std::string& caption, gcn::Font* hoverfont, gcn::Image* img)
		:Button(caption),
         mHasMouse(false)
{
	setFrameSize(0);
	mHighLightFont = hoverfont;
	glyph = img;
}


/**
 * We free the sound if this is the last instance.
 */
DXButton::~DXButton()
{
/*	--mInstances;

	if (mInstances == 0)
	{
		Mix_FreeChunk(mHoverSound);
	}*/
}

/*
 * If we have the mouse we should draw the caption with the highlight
 * font, if not we should draw it with the ordinary font.
 */
void DXButton::draw(gcn::Graphics* graphics)
{
	gcn::ClipRectangle cr = graphics->getCurrentClipArea();
	gcn::Color ramka = gcn::Color(0xb8b2a7);
	if (mHasMouse) ramka = gcn::Color(0xffff61); //ramka = gcn::Color(0x9fc7ff);


	//graphics->drawLine(0, 0, cr.width, cr.height);
	
	graphics->setColor(ramka);
	graphics->drawLine(1, 0, cr.width-2, 0);
	graphics->setColor(gcn::Color(0xffffff));
	graphics->drawLine(2, 1, cr.width-2, 1);
	graphics->drawLine(2, 2, cr.width-2, 2);
	graphics->setColor(gcn::Color(0xf2efe8));
	graphics->drawLine(2, 3, cr.width-2, 3);
	graphics->drawLine(2, 4, cr.width-2, 4);
	graphics->setColor(gcn::Color(0xeeeae2));
	graphics->drawLine(2, 5, cr.width-2, 5);

	graphics->setColor(gcn::Color(0xe0dace));
	for(int i=6; i<cr.height-4; i++)
		graphics->drawLine(2, i, cr.width-2, i);

	graphics->setColor(gcn::Color(0xd4d1c2));
	graphics->drawLine(2, cr.height-2, cr.width-2, cr.height-2);
	graphics->setColor(ramka);
	graphics->drawLine(1, cr.height-1, cr.width-2, cr.height-1);
	graphics->setColor(gcn::Color(0xd7d1c7));
	graphics->drawLine(2, cr.height-3, cr.width-2, cr.height-3);
	graphics->setColor(gcn::Color(0xe5e0d5));
	graphics->drawLine(2, cr.height-4, cr.width-2, cr.height-4);

	graphics->setColor(ramka);
	graphics->drawLine(0, 1, 0, cr.height-2);
	graphics->setColor(gcn::Color(0xd9d3c8));
	graphics->drawLine(1, 1, 1, cr.height-2);

	graphics->setColor(ramka);
	graphics->drawLine(cr.width-1, 1, cr.width-1, cr.height-2);



    if (mHasMouse)
	{
		graphics->setFont(mHighLightFont);
		graphics->drawText(getCaption(),4,5); //7,5
	}
	else
	{
		graphics->setFont(getFont());
		graphics->drawText(getCaption(),4,5);
	}

	if ( glyph != NULL ){
		//draw image
		graphics->drawImage( glyph, 7, (cr.height - glyph->getHeight()) /2 );
	}
}

void DXButton::setHighLightFont(gcn::Font* font)
{
	mHighLightFont = font;
}

void DXButton::setImage(gcn::Image* img){
	glyph = img;
}

/*
 * Button is already a MouseListener. Thats why DXButton doesn't
 * need to inherit from MouseListener, mouseEntered is called when the
 * mouse enters the widget. We want to know this in order to play
 * the mouse hover sound and to save a state that we have the mouse.
 */
void DXButton::mouseEntered(gcn::MouseEvent& mouseEvent)
{
    Button::mouseEntered(mouseEvent);
	//Mix_PlayChannel(-1, mHoverSound, 0);
	mHasMouse = true;
}

/*
 * Button is already a MouseListener. Thats why DXButton doesn't
 * need to inherit from MouseListener, mouseExited is called when the
 * mouse exits the widget. We want to know this in order to play
 * the mouse hover sound and to save a state that we have the mouse.
 */
void DXButton::mouseExited(gcn::MouseEvent& mouseEvent)
{
    Button::mouseExited(mouseEvent);
	mHasMouse = false;
}

