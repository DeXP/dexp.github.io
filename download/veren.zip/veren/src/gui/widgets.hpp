/**
 * Code to populate a global Gui object with all the widgets
 * of Guichan.
 */

#include <iostream>
#include <sstream>

#include "graphres.hpp"

#include "veren.h"
#include "workload.h"

#include "dxbutton.hpp"

namespace widgets
{
    gcn::ImageFont* font;
	gcn::ImageFont* hlfont;
    gcn::Container* top;
	gcn::Container* msgContainer;
	gcn::Container* addObjectContainer;
	gcn::Container* addPierContainer;
    gcn::Label* logoLabel;
	gcn::Label* actionLabel;
	gcn::Label* addObjectLabel;
	gcn::Label* addPierLabel;
	gcn::Label* msgString1;
	gcn::Label* msgString2;
    DXButton* addObjectButton;
	DXButton* addForceButton;
	DXButton* addTorqueButton;
	DXButton* addPierButton;
	DXButton* LoadFileButton;
	DXButton* SaveFileButton;
	DXButton* okBtn;
	DXButton* cancelBtn;
	DXButton* msgOkBtn;
	DXButton* msgCancelBtn;
	DXButton* quitBtn;
    //gcn::TextField* textField;
    gcn::Image *image;

	gcn::Icon* msgIcon;

	/*gcn::TextField* xField;
	gcn::Label* xLabel;
	gcn::TextField* yField;
	gcn::Label* yLabel;
	gcn::TextField* zField;
	gcn::Label* zLabel;

	gcn::TextField* xdField;
	gcn::Label* xdLabel;
	gcn::TextField* ydField;
	gcn::Label* ydLabel;
	gcn::TextField* zdField;
	gcn::Label* zdLabel;*/

	gcn::TextField* shiftField;
	gcn::Label* shiftLabel;
	gcn::TextField* dAngleField;
	gcn::Label* dAngleLabel;
	gcn::TextField* vAngleField;
	gcn::Label* vAngleLabel;

	gcn::TextField* valueField;
	gcn::Label* valueLabel;

	gcn::DropDown* wlDropDown;

	gcn::Window *msgWindow;
	int msgAction = MSG_NONE;




	void setMsgBtns(int keys){
		msgWindow->clear();
		msgWindow->add(msgIcon);
		msgWindow->add(msgString1, 55, 3);
		msgWindow->add(msgString2, 55, 23);
		msgIcon->setImage( graphres::GetInfoImage() );
	
		if( (keys == MB_OKCANCEL) || (keys == MB_YESNO) ){
			if( keys == MB_OKCANCEL ){
				//ok/cancel
				msgOkBtn->setCaption("     OK ");
				msgCancelBtn->setCaption("     Cancel ");
			} else {
				//yes/no
				msgOkBtn->setCaption("     Yes ");
				msgCancelBtn->setCaption("     No ");
				msgIcon->setImage( graphres::GetHelpImage() );
			}

			msgWindow->add(msgOkBtn, 60, 45);
			msgWindow->add(msgCancelBtn, 140, 45);
		} else {
			//ok only
			msgOkBtn->setCaption("     OK ");
			msgWindow->add(msgOkBtn, 115, 45);
		}
		msgOkBtn->adjustSize();
		msgCancelBtn->adjustSize();
	}


	class EditKeyListener : public gcn::KeyListener
    {
    public:
		void getData()
		{
			GLdouble tshift, tdangle, tvangle, tvalue;

			std::istringstream shiftstream( shiftField->getText() );
			shiftstream >> tshift;

			std::istringstream vAnglestream( vAngleField->getText() );
			vAnglestream >> tvangle;

			std::istringstream dAnglestream( dAngleField->getText() );
			dAnglestream >> tdangle;

			std::istringstream valuestream( valueField->getText() );
			valuestream >> tvalue;

			globals::mPainter->setNewObjectArgs(tshift, tdangle, tvangle, tvalue);
		}
		void keyPressed(gcn::KeyEvent& keyEvent)
        {
			getData();
        }
		void keyReleased(gcn::KeyEvent& keyEvent)
		{
			//std::cout << "Key released: " << keyEvent.getKey().getValue() << std::endl;
			;
		}

    };

    EditKeyListener* editKeyListener; // A pointer to the above class









class ButtonActionListener : public gcn::ActionListener
    {
    public:
        void action(const gcn::ActionEvent& actionEvent)
        {
            if ( (actionEvent.getSource() == addObjectButton) ||
				 (actionEvent.getSource() == addForceButton) || 
				 (actionEvent.getSource() == addTorqueButton) ||
				 (actionEvent.getSource() == addPierButton) )
            {
				//std::cout << "Yeah! Make the force, Luke!" << std::endl;
				/*xField->setText("0");
				yField->setText("0.45");
				zField->setText("0.2");

				xdField->setText("90");
				ydField->setText("0");
				zdField->setText("0");*/
				shiftField->setText("0");
				dAngleField->setText("90");
				vAngleField->setText("0");

				valueField->setText("0.45");


				if ( actionEvent.getSource() == addForceButton ) globals::mPainter->setNewObjectType(Workload::FORCE);
				if ( actionEvent.getSource() == addTorqueButton ){
					globals::mPainter->setNewObjectType(Workload::TORQUE);
					dAngleField->setText("0");
				}
				if ( actionEvent.getSource() == addPierButton ){
					//addObjectContainer->remove(valueLabel);
					//addObjectContainer->remove(valueField);
					globals::mPainter->setNewObjectType(Workload::PIER);
				}

				
				editKeyListener->getData();

				globals::mPainter->setAddObjectMode(1);

				if( actionEvent.getSource() == addPierButton ) globals::gui->setTop(addPierContainer);
					else globals::gui->setTop(addObjectContainer);

			}else if( ( (actionEvent.getSource() == okBtn) || (actionEvent.getSource() == cancelBtn) ) &&
																	globals::mPainter->isAddObjectMode() ){
				if(actionEvent.getSource() == okBtn){
					globals::mPainter->saveNewObject();
				}
				globals::mPainter->setAddObjectMode(0);
				globals::gui->setTop(top);

			}else if (actionEvent.getSource() == quitBtn){
				//globals::mPainter->setWantsQuit();
				msgAction = MSG_QUIT;
				setMsgBtns(MB_YESNO);
				msgWindow->setCaption("Quit?");
				msgString1->setCaption("Did you really want to");
				msgString2->setCaption("quit?");
				globals::gui->setTop(msgContainer);
			}else if ( actionEvent.getSource() == SaveFileButton ){
				setMsgBtns(MB_OK);
				if( globals::mPainter->SaveFile(SAVE_FILE_NAME) ){
					//ok
					msgWindow->setCaption("Saving completed");
					msgString1->setCaption("Data was saved correctly");
					msgString2->setCaption("to file 'savefile.xml'");
					globals::gui->setTop(msgContainer);
				} else {
					//error
					msgIcon->setImage( graphres::GetForbiddenImage() );
					msgWindow->setCaption("Error!");
					msgString1->setCaption("Something wrong");
					msgString2->setCaption("Could not save file");
					globals::gui->setTop(msgContainer);
				}

			}else if ( actionEvent.getSource() == LoadFileButton ){
				setMsgBtns(MB_OK);
				if( globals::mPainter->LoadFile(SAVE_FILE_NAME) ){
					//ok
					msgWindow->setCaption("Loading completed");
					msgString1->setCaption("Data from file 'savefile.xml'");
					msgString2->setCaption("was loaded correctly");
					globals::gui->setTop(msgContainer);
				} else {
					//error
					msgIcon->setImage( graphres::GetForbiddenImage() );
					msgWindow->setCaption("Error!");
					msgString1->setCaption("Something wrong");
					msgString2->setCaption("Could not load file");
					globals::gui->setTop(msgContainer);
				}

			}


			

        }
    };

    ButtonActionListener* buttonActionListener; // A pointer to the above class















	class MsgButActionListener : public gcn::ActionListener
    {
    public:
        void action(const gcn::ActionEvent& actionEvent)
        {
			if( (actionEvent.getSource() == msgOkBtn) && (msgAction == MSG_QUIT) ){
				globals::mPainter->setWantsQuit();
			}
			msgAction = MSG_NONE;
			setMsgBtns(MB_OK);
           	globals::gui->setTop(top);
        }
    };

    MsgButActionListener* msgButActionListener; // A pointer to the above class








/*
     * List boxes and drop downs need an instance of a list model
     * in order to display a list.
     */
    class WlListModel : public gcn::ListModel
    {
    public:
        int getNumberOfElements()
        {
            return 3;
        }

        std::string getElementAt(int i)
        {
            switch(i)
            {
              case 0:
                  return std::string("Force");
              case 1:
                  return std::string("Torque");
              case 2:
                  return std::string("Pier");
              default: // Just to keep warnings away
                  return std::string("");
            }
        }
    };

    WlListModel wlListModel;







    /**
     * Initialises the widgets example by populating the global Gui
     * object.
     */
    void init()
    {
		// We make an instance of the ActionListeners.
        buttonActionListener = new ButtonActionListener();
		msgButActionListener = new MsgButActionListener();
		editKeyListener = new EditKeyListener();


        // We first create a container to be used as the top widget.
        // The top widget in Guichan can be any kind of widget, but
        // in order to make the Gui contain more than one widget we
        // make the top widget a container.
        top = new gcn::Container();
		//top->setBaseColor(gcn::Color(form_color));
		
		msgContainer = new gcn::Container();
		addObjectContainer = new gcn::Container();
		addPierContainer = new gcn::Container();
        // We set the dimension of the top container to match the screen.
        top->setDimension(gcn::Rectangle( screen_width-form_width, 0, form_width, screen_height));
		msgContainer->setDimension(gcn::Rectangle( 0, 0, screen_width, screen_height)); //fullscreen
		msgContainer->setBaseColor(gcn::Color(0, 0, 0, 200));

		addObjectContainer->setDimension(gcn::Rectangle( screen_width-form_width, 0, form_width, screen_height));
		addPierContainer->setDimension(gcn::Rectangle( screen_width-form_width, 0, form_width, screen_height));

        // Finally we pass the top widget to the Gui object.
        globals::gui->setTop(top);

        // Now we load the font used in this example.
        //font = new gcn::ImageFont("images/fixedfont.bmp", " abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789");
		//font = new gcn::ImageFont("images/rpgfont_thinner.png", " abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.,!?-+/():;%&`'*#=[]\"");
		font = graphres::GetMainFont();

		//hlfont = new gcn::ImageFont("images/rpgfont_thinner_hl.png", " abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.,!?-+/():;%&`'*#=[]\"");
		hlfont = graphres::GetHLFont();

        // Widgets may have a global font so we don't need to pass the
        // font object to every created widget. The global font is static.
        gcn::Widget::setGlobalFont(font);


		// Now we create the widgets

        logoLabel = new gcn::Label(PRODUCT_NAME);
		actionLabel = new gcn::Label("What do you want?");
		addObjectLabel = new gcn::Label("Adding an object :");
		addPierLabel = new gcn::Label("Adding a pier :");

        addObjectButton = new DXButton(" Add an object ");
		addObjectButton->addActionListener( buttonActionListener );
		addObjectButton->setHighLightFont(hlfont);

		addForceButton = new DXButton("     Add a force  ", hlfont, graphres::GetArrowImage() );
		addForceButton->addActionListener( buttonActionListener );
		//addForceButton->setHighLightFont(hlfont);
		//addForceButton->setImage( graphres::GetArrowImage() );


		addTorqueButton = new DXButton("     Add a torque ", hlfont, graphres::GetTorqueImage() );
		addTorqueButton->addActionListener( buttonActionListener );

		addPierButton = new DXButton("     Add a pier    ", hlfont, graphres::GetPierImage() );
		addPierButton->addActionListener( buttonActionListener );


		LoadFileButton = new DXButton("     Load file ", hlfont, graphres::GetLoadImage() );
		LoadFileButton->addActionListener( buttonActionListener );

		SaveFileButton = new DXButton("     Save file ",  hlfont, graphres::GetSaveImage() );
		SaveFileButton->addActionListener( buttonActionListener );


		okBtn = new DXButton("     OK ", hlfont, graphres::GetOKImage() );
		okBtn->addActionListener( buttonActionListener );

		cancelBtn = new DXButton("     Cancel ", hlfont, graphres::GetCancelImage() );
		cancelBtn->addActionListener( buttonActionListener );

		quitBtn = new DXButton("     Quit ", hlfont, graphres::GetExitImage() );
		quitBtn->addActionListener( buttonActionListener );



		msgOkBtn = new DXButton("     OK ", hlfont, graphres::GetOKImage() );
		msgOkBtn->addActionListener( msgButActionListener );

		msgCancelBtn = new DXButton("     Cancel ", hlfont, graphres::GetCancelImage() );
		msgCancelBtn->addActionListener( msgButActionListener );



		wlDropDown = new gcn::DropDown(&wlListModel);




		msgString1 = new gcn::Label("                                     ");
		msgString2 = new gcn::Label("                                     ");

		msgIcon = new gcn::Icon( graphres::GetInfoImage() );

		msgWindow = new gcn::Window("Message");
        msgWindow->setBaseColor(gcn::Color(msg_form_color));
		msgWindow->setPadding(2);

		setMsgBtns(MB_OK);
		
		msgWindow->resizeToContent();

		msgContainer->add(msgWindow, 310, 250);
		//globals::gui->setTop(msgContainer);



		/*xLabel = new gcn::Label("X :");
		xField = new gcn::TextField("               "); //size???
		xField->addKeyListener( editKeyListener );
		yLabel = new gcn::Label("Y :");
		yField = new gcn::TextField("               ");
		yField->addKeyListener( editKeyListener );
		zLabel = new gcn::Label("Z :");
		zField = new gcn::TextField("               ");
		zField->addKeyListener( editKeyListener );

		xdLabel = new gcn::Label("Xd :");
		xdField = new gcn::TextField("               ");
		xdField->addKeyListener( editKeyListener );
		ydLabel = new gcn::Label("Yd :");
		ydField = new gcn::TextField("               ");
		ydField->addKeyListener( editKeyListener );
		zdLabel = new gcn::Label("Zd :");
		zdField = new gcn::TextField("               ");
		zdField->addKeyListener( editKeyListener );*/

		shiftField = new gcn::TextField("          ");  //size???
		shiftField->addKeyListener( editKeyListener );
		shiftLabel = new gcn::Label("Shift :");

		dAngleField = new gcn::TextField("          ");
		dAngleField->addKeyListener( editKeyListener );
		dAngleLabel = new gcn::Label("defl Angle :");

		vAngleField = new gcn::TextField("          ");
		vAngleField->addKeyListener( editKeyListener );
		vAngleLabel = new gcn::Label("vert Angle :");


		valueLabel = new gcn::Label("Value :");
		valueField = new gcn::TextField("          ");
		valueField->addKeyListener( editKeyListener );



        //textField = new gcn::TextField("Text field");

        top->add(logoLabel, 35, 10);
		top->add(actionLabel, 10, 40);
        //top->add(addObjectButton, 30, 90);
		top->add(addForceButton, 25, 90);
		top->add(addTorqueButton, 25, 130);
		top->add(addPierButton, 25, 170);

		top->add(LoadFileButton, 35, 270);
		top->add(SaveFileButton, 35, 310);

		top->add(quitBtn, 60, screen_height-40);
        //top->add(textField, 10, 200);
		
		addObjectContainer->add(logoLabel, 35, 10);
		addObjectContainer->add(addObjectLabel, 10, 40);

		/*addForceContainer->add(xLabel, 10, 70);
		addForceContainer->add(xField, 75, 67);
		addForceContainer->add(yLabel, 10, 100);
		addForceContainer->add(yField, 75, 97);
		addForceContainer->add(zLabel, 10, 130);
		addForceContainer->add(zField, 75, 127);

		addForceContainer->add(xdLabel, 10, 160);
		addForceContainer->add(xdField, 75, 157);
		addForceContainer->add(ydLabel, 10, 190);
		addForceContainer->add(ydField, 75, 187);
		addForceContainer->add(zdLabel, 10, 220);
		addForceContainer->add(zdField, 75, 217);*/

		//addObjectContainer->add(wlDropDown, 10, 50);

		addObjectContainer->add(shiftLabel, 10, 70);
		addObjectContainer->add(shiftField, 105, 67);
		addObjectContainer->add(dAngleLabel, 10, 100);
		addObjectContainer->add(dAngleField, 105, 97);
		addObjectContainer->add(vAngleLabel, 10, 130);
		addObjectContainer->add(vAngleField, 105, 127);

		addObjectContainer->add(valueLabel, 10, 160);
		addObjectContainer->add(valueField, 105, 157);
		
		/*addForceContainer->add(valueLabel, 10, 250);
		addForceContainer->add(valueField, 75, 247);*/


		addObjectContainer->add(okBtn, 10, 200);
		addObjectContainer->add(cancelBtn, 80, 200);





		addPierContainer->add(logoLabel, 35, 10);
		addPierContainer->add(addPierLabel, 10, 40);

		addPierContainer->add(shiftLabel, 10, 70);
		addPierContainer->add(shiftField, 105, 67);
		addPierContainer->add(dAngleLabel, 10, 100);
		addPierContainer->add(dAngleField, 105, 97);
		addPierContainer->add(vAngleLabel, 10, 130);
		addPierContainer->add(vAngleField, 105, 127);


		addPierContainer->add(okBtn, 10, 200);
		addPierContainer->add(cancelBtn, 80, 200);



    }
    
    /**
     * Halts the widgets example.
     */
    void halt()
    {
        delete font;
		delete hlfont;
        delete logoLabel;
		delete actionLabel;
		delete addObjectLabel;
		delete addPierLabel;
        delete addObjectButton;

		delete buttonActionListener;
		delete msgButActionListener;
		delete editKeyListener;

		delete addForceButton;
		delete addTorqueButton;
		delete addPierButton;

		delete LoadFileButton;
		delete SaveFileButton;

		delete top;
		delete addObjectContainer;
		delete addPierContainer;

		delete okBtn;
		delete cancelBtn;
		delete quitBtn;

		delete wlDropDown;

		/*delete xLabel;
		delete yLabel;
		delete zLabel;
		delete xField;
		delete yField;
		delete zField;

		delete xdLabel;
		delete ydLabel;
		delete zdLabel;
		delete xdField;
		delete ydField;
		delete zdField;*/

		delete shiftField;
		delete shiftLabel;
		delete dAngleField;
		delete dAngleLabel;
		delete vAngleField;
		delete vAngleLabel;

		delete valueLabel;
		delete valueField;
		
		delete msgContainer;
		delete msgWindow;

		delete msgOkBtn;
		delete msgCancelBtn;

		delete msgString1;
		delete msgString2;

		delete msgIcon;
    }
}
