#include "coord.h"

float* Coord::GetAllCoord()
{
       float *all=new float[3];
       all[0]=this->x;
       all[1]=this->y;
       all[2]=this->z;
       return all;
}

