#include "workload.h"
#include "torque.h"
#include <math.h>

Torque::Torque(){
	type = Workload::TORQUE;
}

Torque::Torque(Torque *oldTorque){
	type = Workload::TORQUE;
	value = oldTorque->value;
	bCoord.shift = oldTorque->getCoord().shift;
	bCoord.dAngle = oldTorque->getCoord().dAngle;
	bCoord.vAngle = oldTorque->getCoord().vAngle;
}

Torque::Torque(GLdouble shift, GLdouble dAngle, GLdouble vAngle, GLdouble value){
	type = Workload::TORQUE;
	this->value = value;
	bCoord.shift = shift;
	bCoord.dAngle = dAngle;
	bCoord.vAngle = vAngle;
}

int Torque::setTorque(GLdouble shift, GLdouble dAngle, GLdouble vAngle, GLdouble value){
	this->value = value;
	bCoord.shift = shift;
	bCoord.dAngle = dAngle;
	bCoord.vAngle = vAngle;
	return 1;
}

GLdouble Torque::getValue(){
	return value;
}

//procedure CreateTorus(TubeRadius, Radius : GLfloat; Sides, Rings : Integer);
void Torque::CreateTorque(GLfloat TubeRadius, GLfloat Radius, int Sides, int Rings, int Delta){
	int i,j;
	GLfloat theta, phi, theta1;
	GLfloat  cosTheta, sinTheta, cosTheta1, sinTheta1;
	GLfloat ringDelta, sideDelta, cosPhi, sinPhi, dist;

  sideDelta = 2.0 * M_PI / Sides;
  ringDelta = 2.0 * M_PI / Rings;
  theta = 0.0;
  cosTheta = 1.0;
  sinTheta = 0.0;
  
    //TorusDL = glGenLists(1);
  //glNewList(TorusDL, GL_COMPILE);
    for( i= Rings-1; i>=Delta; i--){
      theta1 = theta + ringDelta;
      cosTheta1 = cos(theta1);
      sinTheta1 = sin(theta1);
      glBegin(GL_QUAD_STRIP);
        phi = 0.0;
        for( j = Sides; j>=0; j--)
		{
          phi = phi + sideDelta;
          cosPhi = cos(phi);
          sinPhi = sin(phi);
          dist = Radius + (TubeRadius * cosPhi);

          glNormal3f(cosTheta1 * cosPhi, -sinTheta1 * cosPhi, sinPhi);
          glVertex3f(cosTheta1 * dist, -sinTheta1 * dist, TubeRadius * sinPhi);

          glNormal3f(cosTheta * cosPhi, -sinTheta * cosPhi, sinPhi);
          glVertex3f(cosTheta * dist, -sinTheta * dist, TubeRadius * sinPhi);
        }
      glEnd();
      theta = theta1;
      cosTheta = cosTheta1;
      sinTheta = sinTheta1;
    }
	
	GLUquadricObj *quadObj;
	quadObj = gluNewQuadric(); 
		glTranslated(Radius, 0, 0 );
		gluSphere(quadObj, force_diam, 10, 10);
		glTranslated(-Radius + Radius*sin(ringDelta), Radius*cos(ringDelta), 0 ); //0,0
		//gluSphere(quadObj, force_diam*2, 10, 10);
		glRotated(90, 0,1,0);
		glRotated(15, 1,0,0);
		gluCylinder(quadObj, 0.023 , 0, 0.1, 15, 15);
 	gluDeleteQuadric(quadObj);

  //glEndList();
}


void Torque::draw(){
	GLUquadricObj *quadObj;
	quadObj = gluNewQuadric(); 

	glTranslated( 0, 0, bCoord.shift); 
	glRotated(bCoord.dAngle, 1,0,0);
	glRotated(bCoord.vAngle, 0,1,0);

	//CreateTorus(0.2, force_diam, 10, 10);
	
	if( value >= force_diam ) CreateTorque( force_diam, value/2, 15, 30, 6);
	
	gluDeleteQuadric(quadObj);
}

Torque::~Torque(){
	;
}
