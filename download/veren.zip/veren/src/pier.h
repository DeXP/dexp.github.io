#ifndef PIER_H
#define PIER_H

#include "GL/gl.h"
#include "GL/glu.h"

#include "veren.h"
#include "coord.h"
#include "workload.h"


class Pier : public Workload {
	
	private:

		//BeamCoord bCoord;
		int pierType;
		
	public:	

		Pier();
		Pier(Pier *oldPier);
		Pier(GLdouble shift, GLdouble dAngle, GLdouble vAngle);
		int setPier(GLdouble shift, GLdouble dAngle, GLdouble vAngle);
		void draw();

		~Pier();

};

#endif //FORCE_H
