#ifndef VEREN_H
#define VEREN_H

#define APP_SHORT "VerEn"

#define MY_ENCODING "UTF-8"

#define SAVE_FILE_NAME "savefile.xml"
#define SUP_FILE_VERSION "0.35"

#define screen_width 900
#define screen_height 650
#define screen_x 10
#define screen_y 10

#define form_color 0xece9d8
#define msg_form_color 0xece9d8

#define form_width 180

#define force_diam 0.008

#define MB_OK 1
#define MB_OKCANCEL 3
#define MB_YESNO 9

#define MSG_NONE 0
#define MSG_QUIT 101

#endif //VEREN_H
