#ifndef WORKLOAD_H
#define WORKLOAD_H

#include <string>

#include "GL/gl.h"
#include "GL/glu.h"

#include "coord.h"

class Workload{

	protected:

		BeamCoord bCoord;
		int type;
		
	public:	

		static const int UNDEF  = 0;
		static const int FORCE  = 1;
		static const int TORQUE = 2;
		static const int PIER   = 3;

		static std::string getTypeString(int curType);

		Workload();
		BeamCoord getCoord();
		int getType();
		virtual void draw();

		~Workload();

};


#endif
