#ifndef TORQUE_H
#define TORQUE_H

#include "GL/gl.h"
#include "GL/glu.h"

#include "veren.h"
#include "coord.h"
#include "workload.h"


class Torque : public Workload {
	
	private:

		GLdouble value;
		
		static void CreateTorque(GLfloat TubeRadius, GLfloat Radius, int Sides, int Rings, int Delta);
		
	public:	

		Torque();
		Torque(GLdouble shift, GLdouble dAngle, GLdouble vAngle, GLdouble value);
		Torque(Torque *oldTorque);
		int setTorque(GLdouble shift, GLdouble dAngle, GLdouble vAngle, GLdouble value);
		GLdouble getValue();
		void draw();

		~Torque();

};

#endif //TORQUE_H
