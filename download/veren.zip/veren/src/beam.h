#ifndef BEAM_H
#define BEAM_H

#include "coord.h"
#include "workload.h"
#include "force.h"
#include "torque.h"
#include "pier.h"

class Beam{ // balka

	private:

		FullCoord fcoord; //current object's full coordinates (with rotation)
		GLdouble height;
		GLdouble radius;

	
	public:

		Workload *objects[100]; //All beam's objects: forces, torques, piers etc
		int objectsCount;
		Workload *tempObj;

		Beam(GLdouble Height,GLdouble Radius, GLdouble x, GLdouble y, GLdouble z);
		Beam(GLdouble Height, GLdouble Radius, GLdouble x, GLdouble y, GLdouble z, GLdouble xr, GLdouble yr, GLdouble zr);
		GLdouble getRadius();
		GLdouble getHeight();
		FullCoord getCurCoord();
		void addObject();
		void draw();
		~Beam();
};


#endif //BEAM_H
