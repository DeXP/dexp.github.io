#include "GL/gl.h"
#include "GL/glu.h"
#include "veren.h"
#include "coord.h"
#include "beam.h"
#include <math.h>

Beam::Beam(GLdouble Height, GLdouble Radius, GLdouble x, GLdouble y, GLdouble z){
	fcoord.x = x;
	fcoord.y = y;
	fcoord.z = z;
	fcoord.xr = 0;
	fcoord.yr = 0;
	fcoord.zr = 0;
	height = Height;
	radius = Radius;

	objectsCount = 0;
}

Beam::Beam(GLdouble Height, GLdouble Radius, GLdouble x, GLdouble y, GLdouble z, GLdouble xr, GLdouble yr, GLdouble zr){
	fcoord.x = x;
	fcoord.y = y;
	fcoord.z = z;
	fcoord.xr = xr;
	fcoord.yr = yr;
	fcoord.zr = zr;
	height = Height;
	radius = Radius;

	objectsCount = 0;
}


FullCoord Beam::getCurCoord(){
	return fcoord;
}

GLdouble Beam::getRadius(){
	return radius;
}

GLdouble Beam::getHeight(){
	return height;
}

/*void Beam::AddForce(){
	forces[forcesCount] = new Force();
	//forces[forcesCount]->setForce( tempForce->getX(), tempForce->getY(), tempForce->getZ(), tempForce->getXd(), tempForce->getYd(), tempForce->getZd(),tempForce->getValue() );
	forces[forcesCount]->setForce( tempForce->getCoord().shift, tempForce->getCoord().dAngle, tempForce->getCoord().vAngle, tempForce->getValue() );
	forcesCount++;
}*/

void Beam::addObject(){
	int curType = tempObj->getType();
	switch(curType){
		case Workload::FORCE:
			objects[objectsCount] = new Force( dynamic_cast<Force*>(tempObj) );
		break;
		case Workload::TORQUE:
			objects[objectsCount] = new Torque( dynamic_cast<Torque*>(tempObj) );
		break;
		case Workload::PIER:
			objects[objectsCount] = new Pier( dynamic_cast<Pier*>(tempObj) );
		break;
		default:
			objectsCount--;
		break;
	}
	objectsCount++;
}

void Beam::draw(){
	GLUquadricObj *quadObj;
	quadObj = gluNewQuadric();
	
	gluSphere(quadObj, radius, 10, 10);
	gluCylinder(quadObj, radius, radius, height, 15, 15);
	glTranslated(0, 0, height ); // сдвигаемся вправо
	gluSphere(quadObj, radius, 10, 10);
	glTranslated(0, 0, -height ); // сдвигаемся влево

	gluDeleteQuadric(quadObj);
}

Beam::~Beam(){
}
