#include "workload.h"
#include "force.h"

Force::Force(){
	type =  Workload::FORCE;
}

Force::Force(GLdouble value){
	this->value = value;
	type =  Workload::FORCE;
}

Force::Force(GLdouble shift, GLdouble dAngle, GLdouble vAngle, GLdouble value){
	type =  Workload::FORCE;
	this->value = value;
	bCoord.shift = shift;
	bCoord.dAngle = dAngle;
	bCoord.vAngle = vAngle;
}


Force::Force(Force *oldForce){
	type =  Workload::FORCE;
	value = oldForce->value;
	bCoord.shift = oldForce->getCoord().shift;
	bCoord.dAngle = oldForce->getCoord().dAngle;
	bCoord.vAngle = oldForce->getCoord().vAngle;
}


int Force::setForce(GLdouble shift, GLdouble dAngle, GLdouble vAngle, GLdouble value){
	this->value = value;
	bCoord.shift = shift;
	bCoord.dAngle = dAngle;
	bCoord.vAngle = vAngle;
	return 1;
}

GLdouble Force::getValue(){
	return value;
}

void Force::draw(){
	GLUquadricObj *quadObj;
	quadObj = gluNewQuadric(); 

	glTranslated( 0, 0, bCoord.shift); 
	glRotated(bCoord.dAngle, 1,0,0);
	glRotated(bCoord.vAngle, 0,1,0);

	glTranslated(0, 0, - value - 0.08 );
	gluSphere(quadObj, force_diam, 10, 10);
	gluCylinder(quadObj, force_diam , force_diam, value, 15, 15);
	glTranslated(0, 0, 0.08 );
	glTranslated(0, 0, value - 0.12 );
	gluCylinder(quadObj, 0.023 , 0, 0.1, 15, 15);
	glTranslated(0, 0, -value + 0.12 );
	
	gluDeleteQuadric(quadObj);
}

Force::~Force(){
	;
}
