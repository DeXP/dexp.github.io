#include <iostream>

//libxml2 for loading/saving state and preferences
#include <libxml/xmlreader.h>
#include <libxml/xmlmemory.h>
#include <libxml/parser.h>
#include <libxml/xmlwriter.h>

#include "veren.h"
#include "painter.h"
#include "workload.h"
#include "force.h"
#include "torque.h"
#include "pier.h"


Painter::Painter(){
	want_quit = 0;
	addObjectMode = 0;

	//beams[0] = new Beam(0.9, 0.03, -0.65, -0.5, 0); //Length, radius, dx, dy, dz
	beams[0] = new Beam(1.0, 0.025, 0, 0, 0); //Length, radius, dx, dy, dz
	beamsCount = 1;
	curBeam = 0;

	beams[curBeam]->tempObj = new Torque();


	/*if( beams[curBeam]->tempObj == NULL ) std::cout << "tempObject is empty\n";
	beams[curBeam]->tempObj = new Force(66.0);
	std::cout << "Temp obj is: "  << Workload::getTypeString( beams[curBeam]->tempObj->getType() ) << std::endl;*/
	
	//Force *tf = dynamic_cast<Force*>(beams[curBeam]->tempObj);
	//Force* tf = (Force*) beams[curBeam]->tempObj;
	//std::cout << tf->getValue() << " = " << dynamic_cast<Force*>(beams[curBeam]->tempObj)->getValue() << std::endl;

	//rotX = 0.1; rotY = 0.3; rotZ = 0.5;
	rotX = 0; rotY = 0; rotZ = 0;

	//Material colors
	beam_diffuse[0] = 0.1;
	beam_diffuse[1] = 0.5;
	beam_diffuse[2] = 1.0;
	beam_diffuse[3] = 1.0;

	white_light[0] = 1.0;
	white_light[1] = 1.0;
	white_light[2] = 1.0;
	white_light[3] = 1.0;

	active_diffuse[0] = 1.0;
	active_diffuse[1] = 0.0;
	active_diffuse[2] = 0.0;
	active_diffuse[3] = 1.0;

	force_diffuse[0] = 0.0;
	force_diffuse[1] = 1.0;
	force_diffuse[2] = 0.0;
	force_diffuse[3] = 1.0;

	torque_diffuse[0] = 0.3;
	torque_diffuse[1] = 0.1;
	torque_diffuse[2] = 0.8;
	torque_diffuse[3] = 1.0;

	pier_diffuse[0] = 0.9;
	pier_diffuse[1] = 0.9;
	pier_diffuse[2] = 0.5;
	pier_diffuse[3] = 1.0;


	// Init Light

	GLfloat mat_specular[] = {1.0, 1.0, 1.0, 1.0};
	GLfloat mat_shininess[] = {50.0};
	GLfloat light_position[] = {-1.0, 0.3, -1.0, 0.0};
	GLfloat lmodel_ambient[] = {0.5, 0.5, 0.5, 1.0};

	glShadeModel(GL_SMOOTH);
	glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
	glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);

	glLightfv(GL_LIGHT0, GL_POSITION, light_position);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, white_light);
	glLightfv(GL_LIGHT0, GL_SPECULAR, white_light);

	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, lmodel_ambient);

	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glEnable(GL_DEPTH_TEST);

}


/**
 * Main draw function. Draws beams, forces etc
 */
void Painter::draw(){
	//glEnable(GL_LIGHTING);

	glClearColor(0.95f, 0.95f, 0.95f, 1.0f); //background color

	glHint( GL_LINE_SMOOTH_HINT, GL_NICEST );
    //glEnable( GL_LINE_SMOOTH );
    glEnable( GL_BLEND );
    glBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA );

	glLoadIdentity();       
    gluLookAt(0,0.6,0.8, 10,10,10, 0,1,0);
	

    int i, j;

	//Main object drawing circle
	for(i=0; i<beamsCount; i++){
		//Draw each beam
		glTranslated( beams[i]->getCurCoord().x, beams[i]->getCurCoord().y, beams[i]->getCurCoord().z ); 
		glRotated( 90, beams[i]->getCurCoord().xr, beams[i]->getCurCoord().yr, beams[i]->getCurCoord().zr ); 

		glPushMatrix();
			glMaterialfv(GL_FRONT, GL_DIFFUSE, beam_diffuse);
			beams[i]->draw();
		glPopMatrix();

		//glMaterialfv(GL_FRONT, GL_DIFFUSE, white_light);
		if( addObjectMode ){
			//Drawing a temporary object
			glPushMatrix();
				glMaterialfv(GL_FRONT, GL_DIFFUSE, beam_diffuse);
				beams[curBeam]->draw();
				glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, active_diffuse);
				beams[curBeam]->tempObj->draw(); 
			glPopMatrix();
		} else {
			//Draw all existing objects
			glPushMatrix();
				glMaterialfv(GL_FRONT, GL_DIFFUSE, beam_diffuse);
				beams[i]->draw();
			glPopMatrix();

			for(j=0; j<beams[i]->objectsCount; j++){
				glPushMatrix();
					switch( beams[i]->objects[j]->getType() ){
						case Workload::FORCE:
							glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, force_diffuse);
						break;
						case Workload::TORQUE:
							glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, torque_diffuse);
						break;
						case Workload::PIER:
							glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, pier_diffuse);
						break;
					}
					//glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, force_diffuse);
					beams[i]->objects[j]->draw(); 
				glPopMatrix();
			}
		}

	}
			
	//glDisable(GL_LIGHTING);
}


void Painter::setAddObjectMode(int mode){
	addObjectMode = mode;
}

int Painter::isAddObjectMode(){
	return addObjectMode;
}

int Painter::wantsQuit(){
	return want_quit;
}

void Painter::setWantsQuit(){
	 want_quit = 1;
}

/*void Painter::setNewForceArgs(GLdouble shift, GLdouble dAngle, GLdouble vAngle, GLdouble value){
	///if( beams[curBeam]->tempForce == NULL ){	beams[curBeam]->tempForce = new Force();}

	if( shift > beams[curBeam]->getHeight() ) shift = beams[curBeam]->getHeight();
	if( shift < 0 ) shift = 0;

	beams[curBeam]->tempForce->setForce(shift, dAngle, vAngle, value);

	//std::cout << "Tmp force value : " << beams[curBeam]->tempForce->getValue() << std::endl;
}*/

void Painter::setNewObjectArgs(GLdouble shift, GLdouble dAngle, GLdouble vAngle, GLdouble value){
	if( shift > beams[curBeam]->getHeight() ) shift = beams[curBeam]->getHeight();
	if( shift < 0 ) shift = 0;
	switch( beams[curBeam]->tempObj->getType() ){
		case Workload::FORCE:
			dynamic_cast<Force*>(beams[curBeam]->tempObj)->setForce(shift, dAngle, vAngle, value);
		break;
		case Workload::TORQUE:
			dynamic_cast<Torque*>(beams[curBeam]->tempObj)->setTorque(shift, dAngle, vAngle, value);
		break;
		case Workload::PIER:
			dynamic_cast<Pier*>(beams[curBeam]->tempObj)->setPier(shift, dAngle, vAngle);		
		break;
	}
}


void Painter::saveNewObject(){
	beams[curBeam]->addObject();
}

void Painter::setNewObjectType(int newType){
	if( beams[curBeam]->tempObj != NULL ) delete beams[curBeam]->tempObj;
	switch( newType ){
		case Workload::FORCE:
			beams[curBeam]->tempObj = new Force();
		break;
		case Workload::TORQUE:
			beams[curBeam]->tempObj = new Torque();
		break;
		case Workload::PIER:
			beams[curBeam]->tempObj = new Pier();
		break;
		default:
			beams[curBeam]->tempObj = new Force();
		break;
	}
}



int Painter::SaveFile(const char *filename){
	int rc, j;
    xmlTextWriterPtr writer;
    //xmlChar *tmp;

	/* Create a new XmlWriter for uri, with no compression. */
    writer = xmlNewTextWriterFilename(filename, 0);
    if (writer == NULL) {
        fprintf(stderr, "Xmlwriter: Error creating the xml writer");
        return 0;
    }

	/* Start the document with the xml default for the version,
     * encoding  and the default for the standalone
     * declaration. */
    rc = xmlTextWriterStartDocument(writer, NULL, NULL, NULL);
    if (rc < 0) {
        fprintf(stderr, 
            "Xmlwriter: Error at xmlTextWriterStartDocument");
        return 0;
    }

    /* Start an element named "scene". Since thist is the first
     * element, this will be the root element of the document. */
    rc = xmlTextWriterStartElement(writer, BAD_CAST "scene");
    if (rc < 0) {
        fprintf(stderr, 
            "Xmlwriter: Error at xmlTextWriterStartElement");
        return 0;
    }
	
	/* Add an attribute with name "version" and value "1.0" to 'scene' */
	xmlTextWriterWriteAttribute(writer, BAD_CAST "version",
                                     BAD_CAST SUP_FILE_VERSION);

	/* Start an element named "beam" as child of 'scene'. */
    xmlTextWriterStartElement(writer, BAD_CAST "beam");

	xmlTextWriterWriteAttribute(writer, BAD_CAST "type",
                                     BAD_CAST "line");

    xmlTextWriterWriteFormatAttribute(writer, BAD_CAST "length",
                                     "%f", beams[curBeam]->getHeight() );

	xmlTextWriterWriteFormatAttribute(writer, BAD_CAST "radius",
                                     "%f", beams[curBeam]->getRadius() );

	xmlTextWriterWriteFormatAttribute(writer, BAD_CAST "x",
                                     "%f", beams[curBeam]->getCurCoord().x );

	xmlTextWriterWriteFormatAttribute(writer, BAD_CAST "y",
                                     "%f", beams[curBeam]->getCurCoord().y );

	xmlTextWriterWriteFormatAttribute(writer, BAD_CAST "z",
                                     "%f", beams[curBeam]->getCurCoord().z );

	for(j=0; j<beams[curBeam]->objectsCount; j++){
		switch( beams[curBeam]->objects[j]->getType() ){
			case Workload::FORCE:
				xmlTextWriterStartElement(writer, BAD_CAST "force");
				xmlTextWriterWriteFormatAttribute(writer, BAD_CAST "value",
                                     "%f", dynamic_cast<Force*>(beams[curBeam]->objects[j])->getValue() );
			break;
			case Workload::TORQUE:
				xmlTextWriterStartElement(writer, BAD_CAST "torque");
				xmlTextWriterWriteFormatAttribute(writer, BAD_CAST "value",
                                     "%f", dynamic_cast<Torque*>(beams[curBeam]->objects[j])->getValue() );
			break;
			case Workload::PIER:
				xmlTextWriterStartElement(writer, BAD_CAST "pier");
			break;
		}
		xmlTextWriterWriteFormatAttribute(writer, BAD_CAST "shift",
                                     "%f",beams[curBeam]->objects[j]->getCoord().shift );
		xmlTextWriterWriteFormatAttribute(writer, BAD_CAST "dAngle",
                                     "%f",beams[curBeam]->objects[j]->getCoord().dAngle );
		xmlTextWriterWriteFormatAttribute(writer, BAD_CAST "vAngle",
                                     "%f",beams[curBeam]->objects[j]->getCoord().vAngle );

		xmlTextWriterEndElement(writer);
	}
	xmlTextWriterEndElement(writer);



    /* Here we could close the elements using the
     * function xmlTextWriterEndElement, but since we do not want to
     * write any other elements, we simply call xmlTextWriterEndDocument,
     * which will do all the work. */
    rc = xmlTextWriterEndDocument(writer);
    if (rc < 0) {
		fprintf(stderr, 
            "Xmlwriter: Error at xmlTextWriterEndDocument\n");
        return 0;
    }
    xmlFreeTextWriter(writer);
	return 1;
}




int Painter::LoadFile(const char *filename){
	int i;

	xmlDocPtr doc;
    xmlNodePtr cur, top;
    doc = xmlParseFile(filename);

	if (doc == NULL ) {
            fprintf(stderr,"Document not parsed successfully. \n");
            return 0;
    }
    top = xmlDocGetRootElement(doc);
    if (top == NULL) {
            fprintf(stderr,"empty document\n");
            xmlFreeDoc(doc);
            return 0;
    }
    if (xmlStrcmp(top->name, (const xmlChar *) "scene")) {
            fprintf(stderr,"document of the wrong type, root node != scene");
            xmlFreeDoc(doc);
            return 0;
    }

	//cleaning before loading
	for(i=0; i<beamsCount; i++)
		delete beams[i];
	beamsCount = 0;


	top = top->xmlChildrenNode;
	while (top != NULL) { //beams circle
		if ((!xmlStrcmp(top->name, (const xmlChar *)"beam"))){
			//Make this beam
			float length, radius, bx, by, bz, bxr, byr, bzr;
			sscanf( (const char*)xmlGetProp(top, (const xmlChar *)"length"), "%f", &length);
			sscanf( (const char*)xmlGetProp(top, (const xmlChar *)"radius"), "%f", &radius);
			sscanf( (const char*)xmlGetProp(top, (const xmlChar *)"x"), "%f", &bx);
			sscanf( (const char*)xmlGetProp(top, (const xmlChar *)"y"), "%f", &by);
			sscanf( (const char*)xmlGetProp(top, (const xmlChar *)"z"), "%f", &bz);
			sscanf( (const char*)xmlGetProp(top, (const xmlChar *)"xr"), "%f", &bxr);
			sscanf( (const char*)xmlGetProp(top, (const xmlChar *)"yr"), "%f", &byr);
			sscanf( (const char*)xmlGetProp(top, (const xmlChar *)"zr"), "%f", &bzr);
			//printf(" Beam[%d]:\n  Length: %f\n  Radius: %f\n", beamsCount, length, radius);

			beams[beamsCount] = new Beam(length, radius, bx, by, bz, bxr, byr, bzr); //Length, radius, dx, dy, dz

			cur = top->xmlChildrenNode;

			while (cur != NULL) { //current beam's items
				//printf("%s\n", cur->name);
				int num = beams[beamsCount]->objectsCount;
				float shift = 0;
				float dAngle = 0;
				float vAngle = 0;
				float value = 0;

				if ( (!xmlStrcmp(cur->name, (const xmlChar *)"force")) || 
					 (!xmlStrcmp(cur->name, (const xmlChar *)"torque")) ||
					 (!xmlStrcmp(cur->name, (const xmlChar *)"pier")) 
					 ){
					//That is corect object. It will be added
					beams[beamsCount]->objectsCount++;

					//Common attributes
					if( xmlGetProp(cur, (const xmlChar *)"shift")!=NULL ) 
						sscanf( (const char*)xmlGetProp(cur, (const xmlChar *)"shift"), "%f", &shift);
					if( xmlGetProp(cur, (const xmlChar *)"dAngle")!=NULL ) 
						sscanf( (const char*)xmlGetProp(cur, (const xmlChar *)"dAngle"), "%f", &dAngle);
					if( xmlGetProp(cur, (const xmlChar *)"vAngle")!=NULL )
						sscanf( (const char*)xmlGetProp(cur, (const xmlChar *)"vAngle"), "%f", &vAngle);
				}

				if ( (!xmlStrcmp(cur->name, (const xmlChar *)"force")) || 
					 (!xmlStrcmp(cur->name, (const xmlChar *)"torque"))
					 ){

					if( xmlGetProp(cur, (const xmlChar *)"value")!=NULL ) 
						sscanf( (const char*)xmlGetProp(cur, (const xmlChar *)"value"), "%f", &value);
				}

		        if ((!xmlStrcmp(cur->name, (const xmlChar *)"force"))) 
					beams[beamsCount]->objects[num] = new Force(shift, dAngle, vAngle, value);

				
		        if ((!xmlStrcmp(cur->name, (const xmlChar *)"torque")))
					beams[beamsCount]->objects[num] = new Torque(shift, dAngle, vAngle, value);
		        

				if ((!xmlStrcmp(cur->name, (const xmlChar *)"pier")))
					beams[beamsCount]->objects[num] = new Pier(shift, dAngle, vAngle);
		       				
		        cur = cur->next;
		    }

			beamsCount++;
		}
		top = top->next;
	}

	xmlFreeDoc(doc);
	return 1;
}



Painter::~Painter(){
	int i;
	for(i=0; i<beamsCount; i++)
		delete beams[i];
}

