#ifndef PAINTER_H
#define PAINTER_H

#include "GL/gl.h"
#include "GL/glu.h"

#include "beam.h"

class Painter{

	private:

		int curBeam;
		int beamsCount;
		Beam *beams[2];

		int addObjectMode;

		GLfloat beam_diffuse[4];
		GLfloat white_light[4];
		GLfloat active_diffuse[4];
		GLfloat force_diffuse[4];
		GLfloat torque_diffuse[4];
		GLfloat pier_diffuse[4];


		int want_quit;

		GLdouble rotX, rotY, rotZ;


	public:

		Painter();
		void draw();
		void setAddObjectMode(int mode);
		int isAddObjectMode();
		int wantsQuit();
		void setWantsQuit();
		void setNewObjectArgs(GLdouble shift, GLdouble dAngle, GLdouble vAngle, GLdouble value);
		void saveNewObject();
		void setNewObjectType(int newType);
		int SaveFile(const char *filename);
		int LoadFile(const char *filename);
		~Painter();

};

#endif //PAINTER_H
