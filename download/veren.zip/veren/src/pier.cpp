#include "workload.h"
#include "pier.h"

Pier::Pier(){
	type =  Workload::PIER;
}

Pier::Pier(Pier *oldPier){
	type =  Workload::PIER;
	bCoord.shift = oldPier->getCoord().shift;
	bCoord.dAngle = oldPier->getCoord().dAngle;
	bCoord.vAngle = oldPier->getCoord().vAngle;
}

Pier::Pier(GLdouble shift, GLdouble dAngle, GLdouble vAngle){
	type =  Workload::PIER;
	bCoord.shift = shift;
	bCoord.dAngle = dAngle;
	bCoord.vAngle = vAngle;
}


int Pier::setPier(GLdouble shift, GLdouble dAngle, GLdouble vAngle){
	bCoord.shift = shift;
	bCoord.dAngle = dAngle;
	bCoord.vAngle = vAngle;
	return 1;
}

void Pier::draw(){
	GLUquadricObj *quadObj;
	quadObj = gluNewQuadric(); 

	glTranslated( 0, 0, bCoord.shift); 
	glRotated(bCoord.dAngle, 1,0,0);
	glRotated(bCoord.vAngle, 0,1,0);

	gluCylinder(quadObj, 0.025 , 0.04, 0.2, 15, 15);
	
	gluDeleteQuadric(quadObj);
}

Pier::~Pier(){
	;
}
