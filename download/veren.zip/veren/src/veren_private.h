/* THIS FILE WILL BE OVERWRITTEN BY DEV-C++ */
/* DO NOT EDIT ! */

#ifndef VEREN_PRIVATE_H
#define VEREN_PRIVATE_H

/* VERSION DEFINITIONS */
#define VER_STRING	"0.1.3.194"
#define VER_MAJOR	0
#define VER_MINOR	1
#define VER_RELEASE	3
#define VER_BUILD	194
#define COMPANY_NAME	"DeXPeriX a.k.a. Dmitry Hrabrov"
#define FILE_VERSION	"0.1.2.1"
#define FILE_DESCRIPTION	"GUI Engine for Mechanics of materials"
#define INTERNAL_NAME	"veren"
#define LEGAL_COPYRIGHT	"http://dexperix.net"
#define LEGAL_TRADEMARKS	"http://dexperix.net"
#define ORIGINAL_FILENAME	"veren.exe"
#define PRODUCT_NAME	"Vertex Engine"
#define PRODUCT_VERSION	"0.1.2.1"

#endif /*VEREN_PRIVATE_H*/
