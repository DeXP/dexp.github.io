#include <string>
#include "workload.h"

Workload::Workload(){
	type = Workload::UNDEF;
}

BeamCoord Workload::getCoord(){
	return bCoord;
}

int Workload::getType(){
	return type;
}

std::string Workload::getTypeString(int curType){
	std::string typeVal = "";
	switch(curType){
		case Workload::UNDEF:
			typeVal = "Undefined";
		break;
		case Workload::FORCE:
			typeVal = "Force";
		break;
		case Workload::TORQUE:
			typeVal = "Torque";
		break;
		case Workload::PIER:
			typeVal = "Pier";
		break;
	}
	return typeVal;
}

void Workload::draw(){
	;
}

Workload::~Workload(){
	;
}
