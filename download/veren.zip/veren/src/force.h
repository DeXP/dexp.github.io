#ifndef FORCE_H
#define FORCE_H

#include "GL/gl.h"
#include "GL/glu.h"

#include "veren.h"
#include "coord.h"
#include "workload.h"


class Force : public Workload {
	
	private:

		//BeamCoord bCoord;
		GLdouble value;
		
	public:	

		Force();
		Force(GLdouble value);
		Force(GLdouble shift, GLdouble dAngle, GLdouble vAngle, GLdouble value);
		Force(Force *oldForce);
		int setForce(GLdouble shift, GLdouble dAngle, GLdouble vAngle, GLdouble value);
		//BeamCoord getCoord();
		GLdouble getValue();
		void draw();


		~Force();

};

#endif //FORCE_H
