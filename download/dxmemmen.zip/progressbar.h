#ifndef PROGRESSBAR_H
#define PROGRESSBAR_H

#include <string.h>
#include <stdio.h>

/* * * * * * * *
 *  Parameters:
 *   cur - current value
 *   maxn - maximum value
 *   size - size, that progressbar will take, in characters
 *   percents - BOOLEAN! Show info in percents?
 *   currency - string constant
 *   lchar - left delimiter char
 *   rchar - right
 *   full_color - fulled color
 * * * * * * * */
void show_progressbar_verbose(int cur, int maxn, int size, int percents, char* currency, char lchar, char rchar, int full_color_fg, int full_color_bg, int empty_color_fg, int empty_color_bg, int intensity, char full_char, char empty_char);

void show_progressbar(int cur, int maxn, int size, int percents, char* currency);

// percent - current percentage
void show_progressbar_min(int percent);
#endif //PROGRESSBAR_H
