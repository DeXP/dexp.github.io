/*
* partitions - the part of dxMemoryManage
*
* Copyright (C) 2008 Hrabrov Dmitry a.k.a. DeXPeriX
* Web: http://dexperix.net
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*
* In addition, as a special exception, the copyright holders give
* permission to link the code of portions of this program with the
* OpenSSL library under certain conditions as described in each
* individual source file, and distribute linked combinations
* including the two.
* You must obey the GNU General Public License in all respects
* for all of the code used other than OpenSSL.  If you modify
* file(s) with this exception, you may extend this exception to your
* version of the file(s), but you are not obligated to do so.  If you
* do not wish to do so, delete this exception statement from your
* version.  If you delete this exception statement from all source
* files in the program, then also delete it here.
*/


#include <stdlib.h>
#include <stdio.h>
#include "concolor.h"
#include "partitions.h"
#include "dxmemmen.h"

/* -/-/-/-/-/-/-/-/-/-/-/-/- */

struct partition *insert(struct partition **pstart, int memory, int time, int *id, int alg_num){
	struct partition * buffer, *start, *now_part, *best_part, *worst_part, *first_part;
	int we_can = 0; // Can we add this element?
	int empty_size = 0;

    start = *pstart;

	if( start == NULL ){ //Initializtion of the first element
		start = (struct partition*) malloc( sizeof(struct partition) );
		start->next = start;
		start->prev = start;
		start->begin = 0;
		start->size = memory;
		start->ttl = time;
		start->id = ++*id;
        *pstart = start;
		return start;
	} else { //First element already initialized
		//Search, if we can put this element into memory?
		now_part = start;
		best_part = NULL; 
		worst_part = NULL;
		first_part = NULL;
        do{
			if( (now_part->ttl <= 0) && (now_part->size >= memory) ){ //Yeeh! We can do it!
				we_can = 1;
				if(best_part==NULL) best_part = now_part;
				if(worst_part==NULL) worst_part = now_part;
				if(first_part==NULL) first_part = now_part;
				if( now_part->size < best_part->size ) best_part = now_part;
				if( now_part->size > worst_part->size ) worst_part = now_part;
			}
			now_part = now_part->next;
		} while( now_part != start );
	
		if( ! we_can ) return NULL;


		switch(alg_num){
			case A_BESTFIT: now_part = best_part;
							break;
			case A_WORSTFIT: now_part = worst_part;
							break;
			case A_FIRSTFIT: now_part = first_part;
							break;
		}

		//Now we divide now_part into 2 partitions: filled with our structure and empty
		empty_size = now_part->size - memory;

		now_part->ttl = time; //Make it leave. Use this memory, Luke!
		now_part->size = memory;

		if( empty_size!=0 ){ //There is 2 nonzero partitions
			buffer = (struct partition*) malloc( sizeof(struct partition) );
			buffer->prev = now_part;
			buffer->begin = now_part->begin + now_part->size; //!!!
			buffer->size = empty_size;
			buffer->ttl = 0;
			buffer->id = ++*id;
			buffer->next = now_part->next;
			now_part->next = buffer;
			//start->prev = buffer;
			return buffer;
		} else { //There only one partition
			return now_part;
		}
	}
};



/* -/-/-/-/-/-/-/-/-/-/-/-/- */

void show_partitions_table(struct partition *start, int step){
	
	void show_edge(){
		set_fg_color(FG_MAGENTA, 1);
		printf("|");
		restore_def_colors();
	}

	struct partition * now_part;
	int i;
	clear_screen();
	if(start!=NULL){
		printf(" Current step is: ");
		set_fg_color(FG_BLUE, 1);
		printf("%d\n", step);

		set_fg_color(FG_RED, 1);
		printf(" Partitions table: \n");
		restore_def_colors();
		set_fg_color(FG_MAGENTA, 1);
		for(i=0; i<41/*get_term_width()*/; i++) printf("-");
		printf("\n|  ");
		set_fg_color(FG_CYAN, 1);
		printf("ID");
		set_fg_color(FG_MAGENTA, 1);
		printf("  |    ");
		set_fg_color(FG_CYAN, 1);
		printf("Begin");
		set_fg_color(FG_MAGENTA, 1);
		printf("  |      ");
		set_fg_color(FG_CYAN, 1);
		printf("Size"); 
		set_fg_color(FG_MAGENTA, 1);
		printf("  |   ");
		set_fg_color(FG_CYAN, 1);
		printf("TTL");
		set_fg_color(FG_MAGENTA, 1);
		printf(" | ");
		set_fg_color(FG_CYAN, 1);
		//printf("Stored Data\n");
		set_fg_color(FG_MAGENTA, 1);
		printf("\n");
		for(i=0; i<41/*get_term_width()*/; i++) printf("-");
		restore_def_colors();
		printf("\n");
		now_part = start;
        do {
			show_edge();
			printf(" %3d. ", now_part->id);
			show_edge();
			printf(" %9d ", now_part->begin);
			show_edge();
			printf(" %10d ", now_part->size);
			show_edge();
			printf(" %5d ", now_part->ttl);
			show_edge();
			printf("\n");
			now_part = now_part->next;
		} while( now_part != start );
		
		set_fg_color(FG_MAGENTA, 1);
		for(i=0; i<41/*get_term_width()*/; i++) printf("-");
		restore_def_colors();
		printf("\n *TTL : Time To Live - how much time this memory will be used.");
	} else {
		MME();
		set_fg_color(FG_RED, 1);
		printf(" Partitions table is empty.\n");
		restore_def_colors();
		printf(" Current step is: ");
		set_fg_color(FG_BLUE, 1);
		printf("%d\n", step);

		restore_def_colors();
	}
	press_akey();
}


/* -/-/-/-/-/-/-/-/-/-/-/-/- */

void partition_step(struct partition *start){
	struct partition * now_part, *tmp_part;
	now_part = start;
    do {
		if( now_part->ttl > 0 ) now_part->ttl--; //We live only one step...
		now_part = now_part->next;
	} while( now_part != start );

	
	now_part = start;
    do {
		while( (now_part->ttl == 0 ) && (now_part->next->ttl == 0) && (now_part->next != start) ){ //make 1 from 2
			tmp_part = now_part->next;
			now_part->size += tmp_part->size;
			now_part->next = tmp_part->next;
			now_part->next->prev = now_part;
			free(tmp_part);
		}
		now_part = now_part->next;
	} while( now_part != start );
};


/* -/-/-/-/-/-/-/-/-/-/-/-/- */

struct partition *find_partition(struct partition *start, int cur_id){
	struct partition *now_part, *finded;
	finded = NULL;
	now_part = start;
    do {
		if( now_part->id == cur_id ) finded = now_part;
		now_part = now_part->next;
	} while( now_part != start );
	return now_part;
};


/* -/-/-/-/-/-/-/-/-/-/-/-/- */


int get_used_memory(struct partition *start){
	struct partition * now_part;
	int mem = 0;
	now_part = start;
    do {
		if( now_part->ttl > 0 ) mem += now_part->size; //used
		now_part = now_part->next;
	} while( now_part != start );
	return mem;
}

/* -/-/-/-/-/-/-/-/-/-/-/-/- */

void partitions_free(struct partition *start){
	struct partition * now_part;
	now_part = start->next;
    do {
		free(now_part->prev);
		now_part = now_part->next;
	} while( now_part != start );
}
