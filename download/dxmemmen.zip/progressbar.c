#include <string.h>
#include <stdio.h>
#include "concolor.h"

void show_progressbar_verbose(int cur, int maxn, int size, int percents, char* currency, char lchar, char rchar, int full_color_fg, int full_color_bg, int empty_color_fg, int empty_color_bg, int intensity, char full_char, char empty_char){
	int curlen, plen, blocks, curpc, i, cbp, changed;
	char cc[10];
	init_colors();
	if( maxn == 0 ) return;
	if( size == 0 ) size = get_term_width();
	if(!percents){
		curlen = strlen(currency);
		sprintf(cc, "%d", cur);
		plen = strlen(cc);
	}else{
		curlen = 1;
		plen = 3;
	}
	curpc = (int) ( 100*cur/maxn );
	if( curpc > 100 ) curpc = 100;
	blocks = size - curlen - plen - 4;
	printf("%c",lchar);
	save_colors();
	changed = 0;
	if( full_color_bg != -1) set_colors(full_color_fg, full_color_bg, intensity);
	  else if( full_color_fg != -1) set_fg_color(full_color_fg, intensity);
	    else restore_def_colors();

	for(i=0; i<blocks; i++){
		cbp = (int) ( 100*i/blocks );
		if(changed) printf("%c", empty_char);
		  else printf("%c", full_char);
		if( (cbp >= curpc) && !changed ){
			if( empty_color_bg != -1) set_colors(empty_color_fg, empty_color_bg, intensity);
				else if( empty_color_fg != -1 ) set_fg_color(empty_color_fg, intensity);
				  else restore_def_colors();
			changed = 1;
		}
	}
	load_colors();
	printf("%c ", rchar);
	if(percents) printf("%d%% ", curpc);
	  else printf("%d%s", cur, currency);
}

void show_progressbar(int cur, int maxn, int size, int percents, char* currency){
	show_progressbar_verbose( cur, maxn, size, percents, currency, '[', ']', FG_BLUE, BG_BLUE, -1, -1, 0, '#', ' ');
}

void show_progressbar_min(int percent){
	show_progressbar_verbose( percent, 100, 0, 1, "", '[', ']', FG_BLUE, BG_BLUE, -1, -1, 0, '#', ' ');
}

/*int main(void){
	char* message = "Free memory: ";
	char* gs = "Installation process: ";
	init_colors();

	set_colors(FG_MAGENTA, BG_CYAN, 1);
	printf("%s", message);
	show_progressbar_verbose(413, 512, get_term_width()-strlen(message), 0, " MB", '{', '}', FG_RED, BG_BROWN, FG_BLUE, BG_CYAN, 1, '#', '_');
	restore_def_colors();
	printf("\n\n\r");

	show_progressbar_min(73);
	printf("\n\n\r");

	set_fg_color(FG_RED, 1);
	printf("%s", gs);
	show_progressbar( 12645, 34876, get_term_width()-strlen(gs), 1, " files");
	restore_def_colors();
	printf("\n\r");
	
	app_exit("Good bye! :)");

	return 0;
}*/
