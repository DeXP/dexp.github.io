#ifndef MEMMEN_H
#define MEMMEN_H

//#define DEBUG 1
//#define DEBUG_KEYS 1


#define MEM_SIZE 65535
#define RND_PRC 3
#define RND_TTL 50

#define M_ADD_ELEMENT 2
#define M_SHOW_PTABLE 3
#define M_ADD_RANDOM 4
#define M_NEXT_STEP 5
#define M_STATISTICS 6
#define M_EDIT 7
#define M_HELP 8
#define M_QUIT 9

#define A_BESTFIT 1
#define A_WORSTFIT 2
#define A_FIRSTFIT 3
#define A_DEFAULT 1
#define A_BAD -1

void press_akey();
void MME();

#endif
