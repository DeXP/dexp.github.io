/* * * * * * * * * * * * * * * * * * * * * * * * * *

Copyright (c) 2008-2009  DeXPeriX a.k.a. Hrabrov Dmitry      http://dexperix.net
 
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

* * * * * * * * * * * * * * * * * * * * * * * * * */

#include "concolor.h"
#include <stdio.h>

int is_saved = 0;
int is_initialized = 0;

#if defined(WIN32) //OS

CONSOLE_SCREEN_BUFFER_INFO csbiInfo;
HANDLE hStdout;
WORD wOldColorAttrs, wSavedColorAttrs; 

void init_colors(){
  if(!is_initialized){
    hStdout = GetStdHandle(STD_OUTPUT_HANDLE);
    GetConsoleScreenBufferInfo(hStdout, &csbiInfo);
    wOldColorAttrs = csbiInfo.wAttributes;
    is_initialized = 1;
  }
};

void restore_def_colors(){
  SetConsoleTextAttribute(hStdout, wOldColorAttrs);
};

void save_colors(){
  hStdout = GetStdHandle(STD_OUTPUT_HANDLE);
  GetConsoleScreenBufferInfo(hStdout, &csbiInfo);
  wSavedColorAttrs = csbiInfo.wAttributes;
  is_saved = 1;
};

void load_colors(){
  if(is_saved) SetConsoleTextAttribute(hStdout, wSavedColorAttrs);  
    else restore_def_colors();
};

void set_colors(int fg_color, int bg_color, int intensity){
  int nowcolor = fg_color | bg_color;
  if(intensity) nowcolor = nowcolor | FOREGROUND_INTENSITY;
  SetConsoleTextAttribute(hStdout, nowcolor );
};

void set_fg_color(int color, int intensity){
  int nowcolor = color;
  if(intensity) nowcolor = nowcolor | FOREGROUND_INTENSITY;
  SetConsoleTextAttribute(hStdout, nowcolor );
};

int congetch(){
	return getch();
}

int get_term_height(){
  COORD conSize;
  hStdout = GetStdHandle(STD_OUTPUT_HANDLE);
  GetConsoleScreenBufferInfo(hStdout, &csbiInfo);
  conSize = csbiInfo.dwSize;
  if( conSize.X == 80 ) return 25; //Standart Windows buffer size
    else return (int)conSize.Y; //xD
};

int get_term_width(){
  COORD conSize;
  hStdout = GetStdHandle(STD_OUTPUT_HANDLE);
  GetConsoleScreenBufferInfo(hStdout, &csbiInfo);
  conSize = csbiInfo.dwSize;
  return (int)conSize.X;
};

void move( int x, int y )
{
   COORD xy;
   xy.X = x;
   xy.Y = y;
   SetConsoleCursorPosition( GetStdHandle( STD_OUTPUT_HANDLE ), xy );
}

void clear_screen(){
  system("cls");
};

void app_exit(char * message){
  printf("\n\r%s", message);
  restore_def_colors();
  getch();
};

#elif defined(__MSDOS__) //OS

int norm_mode, saved_mode;

void init_colors(){
  struct text_info ti;
  gettextinfo(&ti);
  norm_mode = ti.normattr;
  is_initialized = 1;
};

void restore_def_colors(){
  textattr(norm_mode);
};

void save_colors(){
  struct text_info ti;
  gettextinfo(&ti);
  saved_mode = ti.attribute;
  is_saved = 1;
};

void load_colors(){
  if(is_saved) textattr(saved_mode);
    else restore_def_colors();
};

void set_colors(int fg_color, int bg_color, int intensity){
  int nowcolor = fg_color;
  if(intensity) nowcolor += 8;
  textcolor(nowcolor);
  textbackground(bg_color);
};

void clear_screen(){
  clrscr();
};

int congetch(){
	return getch();
}

int get_term_height(){
  struct text_info ti;
  gettextinfo(&ti);
  return ti.screenheight;
};

int get_term_width(){
  struct text_info ti;
  gettextinfo(&ti);
  return ti.screenwidth;
};
void move ( int x, int y){
  gotoxy(x,y);
};

void app_exit(char * message){
  printf("\n\r%s", message);
  restore_def_colors();
  getch();
};
#else //OS
//Linux, Unix etc

int saved_fg_color, saved_intensity, saved_bg_color,
    now_fg_color, now_intensity;
int now_bg_color = -1;
int is_colored = 0;

void init_colors(){
 is_initialized = 1;
};

void set_colors(int fg_color, int bg_color, int intensity){
  is_colored = 1;
  now_fg_color = fg_color;
  now_bg_color = bg_color;
  now_intensity = intensity;
  if(intensity) printf("\033[0;%d;%dm", bg_color, fg_color);
    else printf("\033[2;%d;%dm", bg_color, fg_color);
}

void set_fg_color(int color, int intensity){
  is_colored = 1;
  now_fg_color = color;
  now_intensity = intensity;
  if(intensity) printf("\033[0;%dm", color);
    else printf("\033[2;%dm", color);
}

void restore_def_colors(){
  printf("\033[0;0;0m");
  now_fg_color = -1;
  now_bg_color = -1;
  is_colored = 0;
  is_saved = 0;
}

void save_colors(){
  if(is_colored){
    saved_fg_color = now_fg_color;
    saved_bg_color = now_bg_color;
	saved_intensity = now_intensity;
	is_saved = 1;
  }
}

void load_colors(){
  if(is_saved){
	if(saved_bg_color != -1) set_colors(saved_fg_color, saved_bg_color, saved_intensity);
	  else set_fg_color(saved_fg_color, saved_intensity);
  } else restore_def_colors();
}

int congetch() {
  int c;
  struct termios term;

  /* Get current terminal mode. */
  tcgetattr(0, &term);
  /* Disable ICANON and ECHO. */
  term.c_lflag &= ~(ICANON | ECHO);
  tcsetattr(0, TCSANOW, &term);

  /* Wait for user input. */
  read(0, &c, 1);

  /* Restore normal terminal mode. */
  term.c_lflag |= ICANON | ECHO;
  tcsetattr(0, TCSANOW, &term);

  return c;
}

int get_term_height(){
  struct winsize ws;
  ioctl( fileno(stdin), TIOCGWINSZ, &ws);
  return (int)ws.ws_row;
}

int get_term_width(){
  struct winsize ws;
  ioctl( fileno(stdin), TIOCGWINSZ, &ws);
  return (int)ws.ws_col;
}

void move( int x, int y ){
  printf("\033[%d;%dH", x, y);
};

void clear_screen(){
  printf("\033[2J\033[1;1H");
};

void app_exit(char * message){
  printf("\n\r%s\n", message);
  restore_def_colors();
};

#endif //OS

void reset_string(){
  printf("\r");
};

int get_console_height(){
  return get_term_height();
}

int get_console_width(){
  return get_term_width();
}


int colprintf ( dxcolors colors, const char * format, ... ){
  if( colors.bg_color != BG_SKIP ) set_colors( colors.fg_color, colors.bg_color, colors.intensity );
    else set_fg_color( colors.fg_color, colors.intensity); 
  int len;
  va_list ap;
  va_start(ap, format);
  len = vprintf(format, ap);
  va_end(ap);
  restore_def_colors();
  return len;
}

